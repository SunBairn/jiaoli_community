create
    definer = root@`%` procedure getData()
BEGIN
DECLARE i INT;
SET i=1;
WHILE i<81 DO
INSERT into tb_notice (title,`name`,content,createtime,modifiedtime) value 
		(CONCAT("公告",i),"电信分院",CONCAT("这是公告",i,"的内容"),NOW(),NOW());
SET i=i+1;
END WHILE;
END;

